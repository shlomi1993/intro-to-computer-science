#ifndef __RESULT_H
#define __RESULT_H

typedef enum {
    SUCCESS, FAILURE, MEM_ERROR
} Result;

#endif
